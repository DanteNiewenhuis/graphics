/* Computer Graphics, Assignment 1, Bresenham's Midpoint Line-Algorithm
 *
 * Filename ........ mla.c
 * Description ..... Midpoint Line Algorithm
 * Created by ...... Jurgen Sturm
 *
 * Student name ....
 * Student email ...
 * Collegekaart ....
 * Date ............
 * Comments ........
 *
 *
 * (always fill in these fields before submitting!!)
 */

#include "SDL.h"
#include "init.h"

/*
 * Midpoint Line Algorithm
 *
 * As you probably will have figured out, this is the part where you prove
 * your programming skills. The code in the mla function should draw a direct
 * line between (x0,y0) and (x1,y1) in the specified color.
 *
 * Until now, the example code below draws only a horizontal line between
 * (x0,y0) and (x1,y0) and a vertical line between (x1,y1).
 *
 * And here the challenge begins..
 *
 * Good luck!
 *
 *
 */
 
// calculates initial d
int delta(int x0, int y0, int x1, int y1, float x, float y) {
  return (y0-y1)*x + (x1-x0)*y + x0*y1 - x1*y0;
}

// swaps two values stored at location pointed to by pointers
void swap(int* x, int* y) {
  int s = *x;
  *x = *y;
  *y = s;
}
 
 
void mla(SDL_Texture *t, int x0, int y0, int x1, int y1, Uint32 colour) {
  int d, x, y;
  
  // put end pixels
  PutPixel(t, x0, y0, colour);
  PutPixel(t, x1, y1, colour);
  
  // Ensure x1 >= x0 by swapping (if needed). It makes sure that the left
  // side of the circle is automatically done for us.
  if (x0 > x1) {
    swap(&x0, &x1);
    swap(&y0, &y1);
  }
 
  int x0s, x_delta, y_delta, comp, s;
  float y0s;
  // tackle nearly horizontal top actant
  if ((y1 >= y0) && (x1-x0) >= (y1-y0)) {
    x0s = x0+1;
    y0s = y0+0.5;
    x_delta = 1;
    y_delta = 1;
    comp = -1;
    s = 0;
  // tackle nearly horizontal top actant
  } else if ((y0 > y1) && (x1-x0) >= (y0-y1)) {
    x0s = x0+1;
    y0s = y0-0.5;
    x_delta = 1;
    y_delta = -1;
    comp = 1;
    s = 0;
  } else if ((y0 <= y1) && (y1-y0) >= (x1-x0)) {
    swap(&x0, &y0);
    swap(&x1, &y1);
    x0s = x0+1;
    y0s = y0+0.5;
    x_delta = 1;
    y_delta = 1;
    comp = -1;
    s = 1;
  } else {
    swap(&x0, &y0);
    swap(&x1, &y1);
    x0s = x0-1;
    y0s = y0+0.5;
    x_delta = -1;
    y_delta = 1;
    comp = 1;
    s = 1;
  }
          
  d = delta(x0, y0, x1, y1, x0s, y0s);
  for (x=x0, y=y0; x!=x1; x=x+x_delta) {
    if (s) {
      PutPixel(t, y, x, colour);
    } else {
      PutPixel(t, x, y, colour);
    }
    if (comp*d > 0) {
      y = y + y_delta;
      d = d + x_delta*(y0 - y1) + y_delta*(x1 - x0);
    } else {
      d = d + x_delta*(y0 - y1);
    }
  }
  
  /*
  // put end pixels
  PutPixel(t, x0, y0, colour);
  PutPixel(t, x1, y1, colour);
  
  // Ensure x1 >= x0 by swapping (if needed).
  // This takes care of the left side of the circle.
  if (x0 > x1) {
    x = x0;
    y = y0; 
    x0 = x1;
    y0 = y1;
    x1 = x;
    y1 = y;
  }
    
  // tackle nearly horizontal bottom octant
  if ((y1 >= y0) && (x1-x0) >= (y1-y0)) {
    
    d = delta(x0, y0, x1, y1, x0+1, y0+0.5);
    for (x=x0, y=y0; x!=x1; x++) {
      PutPixel(t, x, y, colour);
      if (d < 0) {
        y = y + 1;
        d = d + (y0 - y1) + (x1 - x0);
      } else {
        d = d + (y0 - y1);
      }
    }
  }
  
  // tackle nearly horizontal top actant
  if ((y0 > y1) && (x1-x0) >= (y0-y1)) {

    d = delta(x0, y0, x1, y1, x0+1, y0-0.5);
    for (x=x0, y=y0; x!=x1; x++) {
      PutPixel(t, x, y, colour);
      if (d > 0) {
        y = y - 1;
        d = d + (y0 - y1) - (x1 - x0);
      } else {
        d = d + (y0 - y1);
      }
    }
  }
  
  // tackle nearly vertical bottom octant
  if ((y0 <= y1) && (y1-y0) >= (x1-x0)) {
    
    d = delta(y0, x0, y1, x1, y0+1, x0+0.5);
    for (x=x0, y=y0; y!=y1; y++) {
      PutPixel(t, x, y, colour);
      if (d < 0) {
        x = x + 1;
        d = d + (x0 - x1) + (y1 - y0);
      } else {
        d = d + (x0 - x1);
      }
    }
  }

  // tackle nearly vertical top octant
  if ((y0 > y1) && (y0-y1) >= (x1-x0)) {

    d = delta(y0, x0, y1, x1, y0-1, x0+0.5);
    for (x=x0, y=y0; y!=y1; y--) {
      PutPixel(t, x, y, colour);
      if (d > 0) {
        x = x + 1;
        d = d - (x0 - x1) + (y1 - y0);
      } else {
        d = d - (x0 - x1);
      }
    }
  }
  */

  return;
}
