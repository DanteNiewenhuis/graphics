/* Computer Graphics assignment, Triangle Rasterization
 * Filename ........ trirast.c
 * Description ..... Implements triangle rasterization
 * Created by ...... Paul Melis
 *
 * Student name ....
 * Student email ...
 * Collegekaart ....
 * Date ............
 * Comments ........
 *
 *
 * (always fill in these fields before submitting!!)
 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "types.h"

/*
 * Rasterize a single triangle.
 * The triangle is specified by its corner coordinates
 * (x0,y0), (x1,y1) and (x2,y2).
 * The triangle is drawn in color (r,g,b).
 */
 
float min(float a, float b, float c) {
  float x_min;
  x_min = (a <= b) ? a : b;
  x_min = (x_min <= c) ? x_min : c;
  return x_min;
}

float max(float a, float b, float c) {
  float x_max;
  x_max = (a > b) ? a : b;
  x_max = (x_max > c) ? x_max : c;
  return x_max;
}

float f(float x0, float y0, float x1, float y1, float x, float y) {
  return (y0-y1)*x + (x1-x0)*y + x0*y1 - x1*y0;
}


void
draw_triangle(float x0, float y0, float x1, float y1, float x2, float y2,
    byte r, byte g, byte b)
{
  // determine bounding box
  float x_min, x_max, y_min, y_max;
  x_min = floor(min(x0, x1, x2));
  y_min = floor(min(y0, y1, y2));
  x_max = ceil(max(x0, x1, x2));
  y_max = ceil(max(y0, y1, y2));
  
  // pre-compute f values 
  float alpha, beta, gamma;
  float fa = f(x1, y1, x2, y2, x0, y0);
  float fb = f(x2, y2, x0, y0, x1, y1);
  float fg = f(x0, y0, x1, y1, x2, y2);
  
  // calculate f value for off-screen point (-1, -1)^T.
  float fa_off = f(x1, y1, x2, y2, -1, -1);
  float fb_off = f(x2, y2, x0, y0, -1, -1);
  float fg_off = f(x0, y0, x1, y1, -1, -1);
  
  // Loop though bounding box and fill in pixels if in triangle
  for (float y=y_min; y<y_max; y++) {
    for (float x=x_min; x<x_max; x++) {
      alpha = f(x1, y1, x2, y2, x, y) / fa;
      beta = f(x2, y2, x0, y0, x, y) / fb;
      gamma = 1.0 - (alpha + beta);
      if (alpha>=0 && beta>=0 && gamma>=0) {
        if ((alpha > 0 || (fa*fa_off) > 0) && (beta > 0 || (fb*fb_off) > 0) && (gamma > 0 || (fg*fg_off) > 0)) {
          PutPixel(x, y, r, g, b);
        }
      }
    }
  }
}

void
draw_triangle_optimized(float x0, float y0, float x1, float y1, float x2, float y2,
    byte r, byte g, byte b)
{
  float d12, d20, alpha, beta, gamma;

  // determine bounding box
  int x_min, x_max, y_min, y_max;
  x_min = floor(min(x0, x1, x2));
  y_min = floor(min(y0, y1, y2));
  x_max = ceil(max(x0, x1, x2));
  y_max = ceil(max(y0, y1, y2));
  
  // pre-compute f values 
  float fa = f(x1, y1, x2, y2, x0, y0);
  float fb = f(x2, y2, x0, y0, x1, y1);
  float fg = f(x0, y0, x1, y1, x2, y2);
  
  // calculate line sign for off-screen point (-1, -1)^T.
  float fa_off = f(x1, y1, x2, y2, -1, -1);
  float fb_off = f(x2, y2, x0, y0, -1, -1);
  float fg_off = f(x0, y0, x1, y1, -1, -1);
  
  // precompute update value to get rid of the divide in the loop
  float d12_update = (y1 - y2); 
  float d20_update = (y2 - y0);
  
  // Loop though bounding box and fill in pixels if in triangle
  for (int y=y_min; y<y_max; y++) {
  
    // precompute f12 and f20 as s12 and d20 respectively
    d12 = f(x1, y1, x2, y2, x_min, y);
    d20 = f(x2, y2, x0, y0, x_min, y);
  
    for (int x=x_min; x<x_max; x++) {
      alpha = d12 / fa;
      beta = d20 / fb;
      gamma = 1.0 - (alpha + beta);
      if (alpha>=0 && beta>=0 && gamma>=0) {
        if ((alpha > 0 || (fa*fa_off) > 0) && (beta > 0 || (fb*fb_off) > 0) && (gamma > 0 || (fg*fg_off) > 0)) {
          PutPixel(x, y, r, g, b);
        }
      }
      
      // update d12 and d20
      d12 += d12_update;
      d20 += d20_update;
    }
  }
}
